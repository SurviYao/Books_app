package com.book;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TypeServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public TypeServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String type = new String(request.getParameter("type").getBytes(
				"ISO-8859-1"), "UTF-8");
		Connection con = new DBUtil().getConnection();
		if (con != null) {
			String sql = "SELECT * FROM book WHERE TYPE=?";
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, type);
				ResultSet rs = ps.executeQuery();
				List<Book> oBooks = new ArrayList<Book>();
				while (rs.next()) {
					int bookid = rs.getInt("bookid");
					String bookname = rs.getString("bookname");
					String bookaddress = rs.getString("bookaddress");
					String bookdate = rs.getString("bookdate");
					String author = rs.getString("author");
					String info = rs.getString("info");
					String image = rs.getString("image");
					Book book = new Book(bookid, bookname, type, bookaddress,
							bookdate, info, author, image);
					oBooks.add(book);
				}
				//第二个查询语句：查询数据库，找出所有分类，并且去重复
				String sql1="SELECT DISTINCT TYPE FROM book ";
				ps=con.prepareStatement(sql1);
				rs=ps.executeQuery();
				List<String> oStr=new ArrayList<String>();
				while (rs.next()) {
					oStr.add(rs.getString("type"));
				}
				String sql2 = "SELECT count(*) FROM book WHERE type=?";
				ps = con.prepareStatement(sql2);
				ps.setString(1, type);
				rs = ps.executeQuery();
				int count = 0;
				if (rs.next()) {
					count = rs.getInt(1);
				}
				request.setAttribute("books", oBooks);
				request.setAttribute("strs", oStr);
				request.setAttribute("count", count);
				request.getRequestDispatcher("home.jsp")
				.forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

package com.book;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BookInfoServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public BookInfoServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int bookid=Integer.parseInt(request.getParameter("bookid"));
		//连接数据库，根据书籍编号，查询数据库，将这本书的所有信息查询出来
		Connection con=new DBUtil().getConnection();
		if (con!=null) {
			String sql="SELECT * FROM book WHERE bookid=?";
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setInt(1, bookid);
				ResultSet rs=ps.executeQuery();
				if (rs.next()) {
					String bookname=rs.getString("bookname");
					String type=rs.getString("type");
					String bookaddress=rs.getString("bookaddress");
					String bookdate=rs.getString("bookdate");
					String author=rs.getString("author");
					String info=rs.getString("info");
					String image=rs.getString("image");
					Book book=new Book(bookid, bookname, type,
							bookaddress, bookdate, info, author, image);
					
					//判断当前这本书是否已被该学生借阅，已借阅
					String str = new StreamUtil().getread("E:\\book.txt");
					String[] users = str.split(",");
					String sql1="select * from user_book_info where number=? and bookid=? and state=?";
					ps=con.prepareStatement(sql1);
					ps.setInt(1, Integer.parseInt(users[1]));
					ps.setInt(2, bookid);
					ps.setInt(3, 1);
					rs=ps.executeQuery();
					
					int state=0;
					if (rs.next()) {
						state=1;
					}
					
					request.setAttribute("book", book);
					request.setAttribute("state", state);
					//重定向
					request.getRequestDispatcher("bookinfo.jsp")
					.forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

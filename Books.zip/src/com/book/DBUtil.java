package com.book;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 * jdbc数据连接工具类
 * @author Administrator
 *
 */
public class DBUtil {

	/**
	 * 指定连接数据库的类型和数据库名称
	 * 根据自己的数据库名称和密码进行连接
	 * @return
	 */
	public Connection getConnection() {
		try {
			//调用jdbc数据库包
			Class.forName("com.mysql.jdbc.Driver");
			//获得数据库连接
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/books",
					"root", "admin");
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}

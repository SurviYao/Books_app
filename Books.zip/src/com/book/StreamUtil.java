package com.book;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class StreamUtil {
	public String getread(String path){
		String str="";
		FileInputStream fis;
		try {
			fis = new FileInputStream(path);
			byte[] bytes = new byte[1024];
			int read = -1;
			StringBuilder builder = new StringBuilder();
			while ((read = fis.read(bytes)) != -1) {
				String info = new String(bytes, 0, read);
				builder.append(info);
			}
			str=builder.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}
}

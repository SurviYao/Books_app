package com.book.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.book.BookJYInfo;
import com.book.DBUtil;

public class HisBookBorrowServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public HisBookBorrowServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String number=request.getParameter("number");
		Connection con=new DBUtil().getConnection();
		if (con!=null) {
			String sql="select * from user_book_info where number=? and state=2";
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString(1, number);
				ResultSet rs=ps.executeQuery();
				List<BookJYInfo> oInfos=new ArrayList<BookJYInfo>();
				while (rs.next()) {
					int bookid=rs.getInt("bookid");
					String startdate=rs.getString("startdate");
					String enddate=rs.getString("enddate");
					int state=rs.getInt("state");
					int id=rs.getInt("id");
					
					String sql0="select * from book where bookid=?";
					PreparedStatement ps1=con.prepareStatement(sql0);
					ps1.setInt(1, bookid);
					ResultSet rs1=ps1.executeQuery();
					if (rs1.next()) {
						String bookname=rs1.getString("bookname");
						String bookaddress=rs1.getString("bookaddress");
						String image=rs1.getString("image");
						BookJYInfo info=new BookJYInfo(id, bookid, number, startdate, enddate, state, image, bookname, bookaddress);
						oInfos.add(info);
					}
				}
				
				JSONArray array=new JSONArray();
				for (int i = 0; i < oInfos.size(); i++) {
					JSONObject object=new JSONObject();
					object.put("id", oInfos.get(i).getId());
					object.put("bookid", oInfos.get(i).getBookid());
					object.put("image", oInfos.get(i).getImage());
					object.put("bookname", oInfos.get(i).getBookname());
					object.put("bookaddress", oInfos.get(i).getBookaddress());
					object.put("state", oInfos.get(i).getState());
					object.put("startdate", oInfos.get(i).getStartdate());
					object.put("enddate", oInfos.get(i).getEnddate());
					array.put(object);
				}
				out.print(array.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

package com.book;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * 登录的服务端
 * @author Administrator
 *
 */
public class LoginServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//更改请求和响应对象的编码格式
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//获得学号和密码
		String num=request.getParameter("num");
		String psd=request.getParameter("psd");
		//与数据库进行建立连接
		Connection con=new DBUtil().getConnection();
		if (con!=null) {
			//准备sql语句，根据学号和密码查询数据库当前登录的用户是否存在
			String sql="select * from student where number=? and psd=?";
			//准备执行sql语句
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString(1, num);
				ps.setString(2, psd);
				//查询出来的所有都在结果集中
				ResultSet rs= ps.executeQuery();
				if (rs.next()) {
					//说明用户输入的学号和密码是存在的
					//从结果集中通过字段名根据字段的数据类型获得数据
					int id=rs.getInt("id");
					String name=rs.getString("name");
					String phone=rs.getString("phone");
					File file=new File("E:\\", "book.txt");
					//    file= E:\book.txt
					if (!file.exists()) {
						//如果不存在，则创建文件
						file.createNewFile();
					}
					FileOutputStream fos=new FileOutputStream(file, false);
					String info=id+","+num+","+name+","+psd+","+phone;
					fos.write(info.getBytes());
					fos.close();
					//跳转至首页
					request.getRequestDispatcher("HomeServlet")
					.forward(request, response);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//释放内存
		out.flush();
		//关闭输出流
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
